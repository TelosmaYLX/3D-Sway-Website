﻿#Requires -Version 5.1
<#
    install-to-ae.ps1 —— 把 3D Sway 安装进本机的 Adobe After Effects（Windows）

    只做一件事：把本脚本所在目录里的 3DSway.aex 复制到

        <AE>\Support Files\Plug-ins\3DSway.aex

    可以重复运行；覆盖前会把旧文件备份成 3DSway.aex.bak；复制成功后清掉旧版文件名。

    用法（双击同目录下的 install-to-ae.cmd 效果相同）：

        powershell -NoProfile -ExecutionPolicy Bypass -File install-to-ae.ps1

    常用参数：

        -AeDir <路径>[,<路径>]  指定 AE 安装目录；不给就自动搜索本机所有版本。
                                多个路径用逗号隔开，例如：
                                  -AeDir D:\Software\Adobe\Adobe After Effects 2026
                                  -AeDir "C:\...\Adobe After Effects 2024","D:\...\2026"
        -DryRun                 只报告将要做什么，不写任何文件
        -NoBackup               覆盖前不生成 .bak 备份
        -SourceDir <路径>       源文件 3DSway.aex 所在目录。默认是本脚本所在目录。
        -Pause                  结束时等一次回车（由 .cmd 传入）
#>
[CmdletBinding()]
param(
    [string[]] $AeDir,
    [switch]   $DryRun,
    [switch]   $NoBackup,
    [string]   $SourceDir,
    [switch]   $Pause,
    [switch]   $Elevated
)

$ErrorActionPreference = 'Stop'

# 要安装的文件（源与目标同名，复制到 AE 的 Support Files\Plug-ins）
#   3DSway.aex  效果插件 —— AE「效果 > Sway > 3D Sway」
$PluginFiles = @(
    [pscustomobject]@{ Name = '3DSway.aex'; Label = '效果插件' }
)
$PluginNames = @($PluginFiles | ForEach-Object { $_.Name })

# 旧版本用过的文件名：新版复制成功后从 Plug-ins 里清掉，避免同 match name 重复加载
$LegacyNames = @('3D sway.aex')

# powershell.exe -File 不会把 "a","b" 解析成数组：它整个当成一个参数传进来。
# 所以 -AeDir 两种写法都要认：-AeDir a,b 和 -AeDir "a","b"。
$AeDirList = @()
foreach ($d in @($AeDir)) {
    foreach ($piece in ([string]$d -split ',')) {
        $t = $piece.Trim().Trim('"').Trim()
        if (-not [string]::IsNullOrWhiteSpace($t)) { $AeDirList += $t }
    }
}

# ---------------------------------------------------------------------------
# 输出小工具
# ---------------------------------------------------------------------------
function Write-Title  { param([string]$t) Write-Host ''; Write-Host "== $t" -ForegroundColor Cyan }
function Write-Ok     { param([string]$t) Write-Host "  [OK]   $t" -ForegroundColor Green }
function Write-Warn2  { param([string]$t) Write-Host "  [注意] $t" -ForegroundColor Yellow }
function Write-Err2   { param([string]$t) Write-Host "  [错误] $t" -ForegroundColor Red }
function Write-Info   { param([string]$t) Write-Host "         $t" -ForegroundColor Gray }
function Write-Note   { param([string]$t) Write-Host "         $t" -ForegroundColor DarkGray }

function Test-IsAdmin {
    return ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()
           ).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Test-CanPrompt {
    try { return (-not [Console]::IsInputRedirected) } catch { return $false }
}

function Read-Choice {
    param([string]$Prompt, [string[]]$Valid, [string]$Default)
    while ($true) {
        $a = Read-Host $Prompt
        if ([string]::IsNullOrWhiteSpace($a)) { return $Default }
        $a = $a.Trim().ToUpperInvariant()
        if ($Valid -contains $a) { return $a }
        Write-Host ("  请输入 " + ($Valid -join ' / ')) -ForegroundColor Yellow
    }
}

# 把找到的 AE 位置**带序号**列出来：下面「输入序号选一个」的提示引用的就是这些序号。
function Write-AeInstallList {
    param([object[]]$Installs)
    for ($i = 0; $i -lt $Installs.Count; $i++) {
        Write-Info ("[{0}]  {1}   {2}" -f ($i + 1), $Installs[$i].Name, $Installs[$i].InstallDir)
    }
}

# 多份 AE 时让用户挑，返回要安装的那些（选中一份，或 A = 全部）。
# A 恒在合法输入表里（写成 1..N 的话，N<9 时 A 根本进不去）。
function Select-AeInstalls {
    param([object[]]$Installs)

    if (-not (Test-CanPrompt)) {
        Write-Warn2 ("非交互运行：默认只装最新的一个（{0}）。用 -AeDir 可以指定其它版本。" -f $Installs[0].Name)
        return @($Installs[0])
    }

    $valid = @()
    for ($i = 1; $i -le $Installs.Count; $i++) { $valid += [string]$i }
    $valid += 'A'

    Write-Host ''
    $prompt = "  要装到哪一个？输入序号（1-$($Installs.Count)），或输入 A 全部安装，回车=1："
    $ans = Read-Choice -Prompt $prompt -Valid $valid -Default '1'
    if ($ans -eq 'A') {
        Write-Info ("全部安装（共 {0} 个）。" -f $Installs.Count)
        return @($Installs)
    }
    return @($Installs[[int]$ans - 1])
}

# Test-Path 遇到不存在的盘符（E:\…）会抛 DriveNotFoundException，
# 而 $ErrorActionPreference='Stop' 会把它变成致命错误 —— 扫描候选路径时必须用这个包装。
function Test-PathSafe {
    param([string]$Path)
    if ([string]::IsNullOrWhiteSpace($Path)) { return $false }
    try { return (Test-Path -LiteralPath $Path -ErrorAction Stop) } catch { return $false }
}

# Join-Path 会去问文件系统提供程序：路径落在不存在的盘符上时它会直接抛，
# 拼候选路径要用这个纯字符串版本。
function Join-PathSafe {
    param([string]$Base, [string]$Child)
    if ([string]::IsNullOrWhiteSpace($Base))  { return $Child }
    if ([string]::IsNullOrWhiteSpace($Child)) { return $Base }
    return ($Base.TrimEnd('\', '/') + '\' + $Child.TrimStart('\', '/'))
}

function Test-DirWritable {
    param([string]$Dir)
    if (-not (Test-PathSafe $Dir)) { return $false }
    $probe = Join-PathSafe $Dir ('.3dsway-write-probe-' + [guid]::NewGuid().ToString('N') + '.tmp')
    try {
        [IO.File]::WriteAllText($probe, 'x')
        Remove-Item -LiteralPath $probe -Force
        return $true
    } catch {
        return $false
    }
}

# 文件被别的进程占用（AE 运行中时 .aex 就是这种情况）——比直接 Copy 再报错更早、更准
function Test-FileLocked {
    param([string]$Path)
    if (-not (Test-PathSafe $Path)) { return $false }
    try {
        $fs = [IO.File]::Open($Path, [IO.FileMode]::Open, [IO.FileAccess]::ReadWrite, [IO.FileShare]::None)
        $fs.Close(); $fs.Dispose()
        return $false
    } catch {
        return $true
    }
}

# ---------------------------------------------------------------------------
# AE 安装位置
# ---------------------------------------------------------------------------
function New-AeRecord {
    param([string]$SupportFiles)

    $sf         = $SupportFiles.TrimEnd('\', '/')
    $installDir = Split-Path -Parent $sf
    $name       = Split-Path -Leaf $installDir

    $ver   = ''
    $mYear = [regex]::Match($name, '\d{4}')
    $mVer  = [regex]::Match($name, '\d+\.\d+')
    if ($mYear.Success) { $ver = $mYear.Value } elseif ($mVer.Success) { $ver = $mVer.Value }

    [pscustomobject]@{
        Name         = $name
        Version      = $ver
        InstallDir   = $installDir
        SupportFiles = $sf
        PluginsDir   = Join-PathSafe $sf 'Plug-ins'
        Exe          = Join-PathSafe $sf 'AfterFX.exe'
    }
}

# 用户给的路径可能是「安装目录」，也可能是「Support Files」本身
function Resolve-SupportFiles {
    param([string]$Path)
    if ([string]::IsNullOrWhiteSpace($Path)) { return $null }
    $p = $Path.Trim().Trim('"').TrimEnd('\', '/')
    if (-not (Test-PathSafe $p)) { return $null }
    if (Test-PathSafe (Join-PathSafe $p 'AfterFX.exe'))                { return $p }
    if (Test-PathSafe (Join-PathSafe $p 'Support Files\AfterFX.exe'))  { return (Join-PathSafe $p 'Support Files') }
    if (Test-PathSafe (Join-PathSafe $p 'Plug-ins'))                   { return $p }
    return $null
}

function Get-AeInstallations {
    $table = @{}   # 小写 SupportFiles -> record（顺带去重）

    function Add-Candidate {
        param([string]$SupportFiles, [hashtable]$Table)
        if ([string]::IsNullOrWhiteSpace($SupportFiles)) { return }
        $sf = $SupportFiles.Trim().Trim('"').TrimEnd('\', '/')
        if (-not (Test-PathSafe $sf)) { return }
        $rec = New-AeRecord -SupportFiles $sf
        # 必须像一份真的 AE 安装：要么有 AfterFX.exe，要么至少有 Plug-ins / Scripts 目录
        $plausible = (Test-PathSafe $rec.Exe) -or
                     (Test-PathSafe $rec.PluginsDir) -or
                     (Test-PathSafe (Join-Path $sf 'Scripts'))
        if (-not $plausible) { return }
        $key = $sf.ToLowerInvariant()
        if (-not $Table.ContainsKey($key)) { $Table[$key] = $rec }
    }

    # ① 注册表：AE 自己写下的安装路径（最准）
    $regRoots = @(
        'HKLM:\SOFTWARE\Adobe\After Effects',
        'HKLM:\SOFTWARE\WOW6432Node\Adobe\After Effects',
        'HKCU:\SOFTWARE\Adobe\After Effects'
    )
    foreach ($rr in $regRoots) {
        if (-not (Test-Path $rr)) { continue }
        foreach ($key in @(Get-ChildItem $rr -ErrorAction SilentlyContinue)) {
            $props = $null
            try { $props = Get-ItemProperty -Path $key.PSPath -ErrorAction SilentlyContinue } catch { }
            if (-not $props) { continue }
            if ($props.PSObject.Properties['InstallPath'] -and $props.InstallPath) {
                Add-Candidate -SupportFiles ([string]$props.InstallPath) -Table $table
            }
            if ($props.PSObject.Properties['PluginInstallPath'] -and $props.PluginInstallPath) {
                Add-Candidate -SupportFiles (Split-Path -Parent ([string]$props.PluginInstallPath)) -Table $table
            }
        }
    }

    # ② 常见安装根目录扫描（注册表没写全时兜底）
    $scanRoots = New-Object System.Collections.ArrayList
    foreach ($r in @(${env:ProgramFiles}, ${env:ProgramFiles(x86)}, (Join-PathSafe $env:LOCALAPPDATA 'Programs'),
                     'D:\Software', 'D:\Program Files', 'D:\Adobe', 'E:\Software', 'E:\Adobe')) {
        if ([string]::IsNullOrWhiteSpace($r)) { continue }
        foreach ($sub in @($r, (Join-PathSafe $r 'Adobe'))) {
            if ((Test-PathSafe $sub) -and -not $scanRoots.Contains($sub)) { [void]$scanRoots.Add($sub) }
        }
    }
    foreach ($root in $scanRoots) {
        foreach ($d in @(Get-ChildItem -LiteralPath $root -Directory -ErrorAction SilentlyContinue |
                         Where-Object { $_.Name -like 'Adobe After Effects*' })) {
            Add-Candidate -SupportFiles (Join-Path $d.FullName 'Support Files') -Table $table
        }
    }

    return @($table.Values | Sort-Object -Property @{ Expression = { if ($_.Version) { [int]$_.Version } else { 0 } } } -Descending)
}

# ---------------------------------------------------------------------------
# 运行中的 AE
# ---------------------------------------------------------------------------
function Get-RunningAeInfo {
    $list = @()
    foreach ($p in @(Get-Process -Name AfterFX -ErrorAction SilentlyContinue)) {
        $path = ''
        try { $path = [string]$p.Path } catch { }
        $list += [pscustomobject]@{ Id = $p.Id; Path = $path; Proc = $p }
    }
    return $list
}

# 只关掉属于目标 AE 的那些 AfterFX 进程（正常关窗，不强杀）
function Close-TargetAe {
    param([string]$ExePath)

    $targets = @()
    foreach ($info in (Get-RunningAeInfo)) {
        if ($info.Path -ieq $ExePath) {
            $targets += $info
        } elseif ([string]::IsNullOrEmpty($info.Path)) {
            # 读不到路径就没法确认是不是目标 AE；既然目标 .aex 被锁着，一并关掉，但要说清楚
            Write-Warn2 ("读不到 PID {0} 的 AfterFX.exe 路径，无法确认是否目标版本，也一并关闭。" -f $info.Id)
            $targets += $info
        } else {
            Write-Note ("跳过另一个 AE 进程 PID {0}：{1}" -f $info.Id, $info.Path)
        }
    }
    if ($targets.Count -eq 0) { return $true }

    foreach ($t in $targets) {
        try { [void]$t.Proc.CloseMainWindow() } catch { }
    }

    $deadline = (Get-Date).AddSeconds(90)
    $dots = 0
    while ((Get-Date) -lt $deadline) {
        Start-Sleep -Milliseconds 500
        $still = @()
        foreach ($t in $targets) {
            $t.Proc.Refresh()
            if (-not $t.Proc.HasExited) { $still += $t }
        }
        if ($still.Count -eq 0) { Write-Host ''; return $true }
        $dots++
        if ($dots % 6 -eq 0) { Write-Host '.' -NoNewline }
    }
    Write-Host ''
    return $false
}

# ---------------------------------------------------------------------------
# 复制 + 校验
# ---------------------------------------------------------------------------
function Install-OneFile {
    param([string]$Src, [string]$DstDir, [string]$DstName, [string]$Label)

    $dst = Join-Path $DstDir $DstName

    if ($DryRun) {
        Write-Host ("  [演练] {0}  ->  {1}" -f $Label, $dst) -ForegroundColor DarkGray
        return [pscustomobject]@{ 项目 = $Label; 大小 = 0; 目标 = $dst; 状态 = '演练（未写入）'; 校验 = '-' }
    }

    $backup = ''
    $state  = '新增'
    if (Test-Path -LiteralPath $dst) {
        $state = '覆盖'
        if (-not $NoBackup) {
            $backup = $dst + '.bak'
            Copy-Item -LiteralPath $dst -Destination $backup -Force
            $state = '覆盖（旧文件已备份为 .bak）'
        }
    }

    try {
        Copy-Item -LiteralPath $Src -Destination $dst -Force
    } catch {
        throw ("复制失败：`n      源：{0}`n      目标：{1}`n      原因：{2}" -f $Src, $dst, $_.Exception.Message)
    }

    $h1 = (Get-FileHash -LiteralPath $Src -Algorithm SHA256).Hash
    $h2 = (Get-FileHash -LiteralPath $dst -Algorithm SHA256).Hash
    if ($h1 -ne $h2) { throw "复制后校验失败（内容不一致）：$dst" }

    return [pscustomobject]@{
        项目 = $Label
        大小 = (Get-Item -LiteralPath $dst).Length
        目标 = $dst
        状态 = $state
        校验 = $h2.Substring(0, 12)
    }
}

# ---------------------------------------------------------------------------
# 主流程
# ---------------------------------------------------------------------------
function Invoke-Main {

    # 源文件默认在脚本自己所在的目录；.cmd 用 -SourceDir 显式指定时以它为准。
    $scriptDir = (Get-Location).ProviderPath
    if (-not [string]::IsNullOrEmpty($PSCommandPath)) { $scriptDir = Split-Path -Parent $PSCommandPath }
    if (-not [string]::IsNullOrWhiteSpace($SourceDir)) {
        $sd = $SourceDir.Trim().Trim('"').TrimEnd('\', '/')
        if (-not (Test-PathSafe $sd)) { throw ("-SourceDir 指向的目录不存在：{0}" -f $sd) }
        $scriptDir = $sd
    }

    Write-Host ''
    Write-Host '============================================================' -ForegroundColor Cyan
    Write-Host '   3D Sway  ->  Adobe After Effects  （安装脚本）' -ForegroundColor Cyan
    Write-Host '============================================================' -ForegroundColor Cyan
    if ($DryRun) { Write-Host '   演练模式（-DryRun）：不会写入任何文件' -ForegroundColor Yellow }

    # ---------------- 1/4 源文件 ----------------
    Write-Title '1/4  检查源文件'

    $sources = @()
    $missing = @()
    foreach ($f in $PluginFiles) {
        $p = Join-Path $scriptDir $f.Name
        if (-not (Test-Path -LiteralPath $p)) { $missing += $p; continue }
        $i = Get-Item -LiteralPath $p
        Write-Ok ("{0,-20} {1,10:N0} 字节   {2}   {3}" -f $f.Name, $i.Length, $i.LastWriteTime.ToString('yyyy-MM-dd HH:mm'), $f.Label)
        $sources += [pscustomobject]@{ Name = $f.Name; Path = $p }
    }
    if ($missing.Count -gt 0) {
        throw (("源目录里缺少这些文件：`n      {0}`n  请把本脚本放到插件产物目录（3DSway.aex 所在处）后再运行；" -f ($missing -join "`n      ")) +
               "`n  源文件在别处就用 -SourceDir <目录> 指定。")
    }
    Write-Note ("来源：" + $scriptDir)

    # ---------------- 2/4 找 AE ----------------
    Write-Title '2/4  查找本机的 After Effects'

    $installs = @()
    if ($AeDirList.Count -gt 0) {
        foreach ($d in $AeDirList) {
            if ([string]::IsNullOrWhiteSpace($d)) { continue }
            $sf = Resolve-SupportFiles -Path $d
            if (-not $sf) {
                throw ("指定的 AE 目录不可用：{0}`n  它应该长这样：D:\Software\Adobe\Adobe After Effects 2026`n  （或者直接给到 …\Adobe After Effects 2026\Support Files）" -f $d)
            }
            $installs += New-AeRecord -SupportFiles $sf
        }
        Write-Ok ("使用 -AeDir 指定的位置，共 {0} 个" -f $installs.Count)
    } else {
        $installs = @(Get-AeInstallations)
        if ($installs.Count -eq 0) {
            throw ("没有在本机找到 Adobe After Effects。`n" +
                   "  如果 AE 装在别的盘，用 -AeDir 明确指定，例如：`n" +
                   "      powershell -File install-to-ae.ps1 -AeDir `"D:\Software\Adobe\Adobe After Effects 2026`"")
        }
        Write-Ok ("自动找到 {0} 个 After Effects 安装" -f $installs.Count)
    }

    Write-AeInstallList -Installs $installs

    if ($installs.Count -gt 1 -and $AeDirList.Count -eq 0) {
        $installs = @(Select-AeInstalls -Installs $installs)
    }

    # ---------------- 3/4 目标目录 ----------------
    Write-Title '3/4  检查目标目录'

    foreach ($ae in $installs) {
        if (-not (Test-Path -LiteralPath $ae.PluginsDir)) {
            throw ("这个安装里没有 Plug-ins 目录：{0}`n  它看起来不是一份完整的 AE 安装，请用 -AeDir 指定正确的目录。" -f $ae.PluginsDir)
        }
    }

    # 写权限（Program Files 下必须提权）
    if (-not $DryRun) {
        $denied = @()
        foreach ($ae in $installs) {
            if (-not (Test-DirWritable -Dir $ae.PluginsDir)) { $denied += $ae.PluginsDir }
        }
        if ($denied.Count -gt 0) {
            Write-Err2 '这些目录当前用户写不进去：'
            foreach ($d in ($denied | Select-Object -Unique)) { Write-Info $d }

            $isAdmin = Test-IsAdmin
            if (-not $isAdmin -and -not $Elevated) {
                Write-Host ''
                Write-Host '  需要管理员权限，正在用管理员身份重新启动本脚本（会弹 UAC 确认框）…' -ForegroundColor Yellow
                $argList = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', ('"' + $PSCommandPath + '"'), '-Elevated')
                # -AeDir 是数组参数，多个路径必须用逗号连成一个参数传过去
                $quoted = @()
                foreach ($ae in $installs) { $quoted += ('"' + $ae.SupportFiles + '"') }
                $argList += @('-AeDir', ($quoted -join ','))
                if ($Pause -or (Test-CanPrompt)) { $argList += '-Pause' }
                if ($NoBackup)  { $argList += '-NoBackup' }
                # 提权后跑的还是同一份脚本，源文件位置一起带过去
                $argList += @('-SourceDir', ('"' + $scriptDir + '"'))
                try {
                    $proc = Start-Process -FilePath 'powershell.exe' -Verb RunAs -ArgumentList $argList -PassThru -Wait
                    return [int]$proc.ExitCode
                } catch {
                    throw ("提权失败：{0}`n  请右键 install-to-ae.cmd（或本 .ps1）→ 以管理员身份运行。" -f $_.Exception.Message)
                }
            }
            throw '即使以管理员身份也无法写入上面的目录，请检查文件是否被占用或目录权限被改动。'
        }
        Write-Ok '目标目录可写。'
    }

    # ---------------- 4/4 处理运行中的 AE + 复制 ----------------
    Write-Title '4/4  检查 After Effects 是否正在运行'

    $running = @(Get-RunningAeInfo)
    if ($running.Count -eq 0) {
        Write-Ok 'AE 没在运行，可以放心替换文件。'
    } else {
        foreach ($r in $running) {
            if ($r.Path) { Write-Info ("AfterFX.exe  PID {0}   {1}" -f $r.Id, $r.Path) }
            else         { Write-Info ("AfterFX.exe  PID {0}   (读不到路径，可能是别的用户启动的)" -f $r.Id) }
        }
    }

    $lockedByTarget = @()
    foreach ($ae in $installs) {
        $lockedFiles = @(foreach ($s in $sources) {
            if (Test-FileLocked -Path (Join-Path $ae.PluginsDir $s.Name)) { $s.Name }
        })
        if ($lockedFiles.Count -gt 0) { $lockedByTarget += [pscustomobject]@{ Ae = $ae; Files = $lockedFiles } }
    }

    if ($lockedByTarget.Count -eq 0) {
        Write-Ok '目标插件文件没有被占用。'
    } elseif ($DryRun) {
        Write-Warn2 '目标插件文件正被 After Effects 占用；正式安装时会先问你要不要自动关掉 AE。'
    } else {
        Write-Warn2 ('Plug-ins 里的 {0} 正被 After Effects 占用，不关掉 AE 就换不了。' -f (($lockedByTarget.Files | Select-Object -Unique) -join '、'))
        Write-Note  '（AE 里有没保存的工程时，关闭过程中会弹保存对话框，先保存好再继续。）'

        if (Test-CanPrompt) {
            Write-Host ''
            Write-Host '     [1] 自动关闭 AE 后继续（推荐）' -ForegroundColor White
            Write-Host '     [2] 取消' -ForegroundColor White
            $ans = Read-Choice -Prompt '  请选择（1/2，回车=1）：' -Valid @('1','2') -Default '1'
            if ($ans -eq '2') { throw 'QUIT' }
        } else {
            throw '目标插件文件正在被 After Effects 使用，且当前无法交互提问。请先退出 AE 再运行本脚本。'
        }

        foreach ($item in $lockedByTarget) {
            $ae = $item.Ae
            $ok = Close-TargetAe -ExePath $ae.Exe
            if ($ok) { Write-Ok 'AE 已退出。'; continue }

            Write-Err2 '等了一会儿，AE 还没退出（可能还有没保存的工程，或保存对话框没点掉）。'
            if (-not (Test-CanPrompt)) { throw 'AE 未能自动退出，.aex 无法替换。' }

            $ans2 = Read-Choice -Prompt '  关掉 AE 后输入 C 继续；输入 Q 取消（回车=C）：' -Valid @('C','Q') -Default 'C'
            if ($ans2 -eq 'Q') { throw 'QUIT' }
            $still = @($item.Files | Where-Object { Test-FileLocked -Path (Join-Path $ae.PluginsDir $_) })
            if ($still.Count -gt 0) {
                throw ('{0} 还被占用着。请彻底退出 AE 后重新运行本脚本。' -f ($still -join '、'))
            }
        }
    }

    Write-Title '复制文件'

    $results = @()
    foreach ($ae in $installs) {
        Write-Host ("  {0}" -f $ae.Name) -ForegroundColor White

        foreach ($s in $sources) {
            if ((-not $DryRun) -and (Test-FileLocked -Path (Join-Path $ae.PluginsDir $s.Name))) {
                throw ('{0} 仍然被占用（AE 又起来了？），插件没换。退出 AE 后重新运行本脚本即可。' -f $s.Name)
            }
            $results += Install-OneFile -Src $s.Path -DstDir $ae.PluginsDir -DstName $s.Name -Label $s.Name
        }

        # 旧版本用过的文件名：留着会和同 match name 的新插件重复加载，复制成功后清掉
        if (-not $DryRun) {
            foreach ($legacy in $LegacyNames) {
                $lp = Join-Path $ae.PluginsDir $legacy
                if (-not (Test-PathSafe $lp)) { continue }
                Remove-Item -LiteralPath $lp -Force
                if (Test-PathSafe $lp) { throw ('旧的 {0} 删不掉，请手动删除后再重启 AE。' -f $lp) }
                Write-Warn2 ('已删除旧文件名 {0}。' -f $legacy)
            }
        }

        # Plug-ins 里多出来的同类文件（不同版本/调试副本）容易互相干扰，提醒一下
        $extra = @(Get-ChildItem -LiteralPath $ae.PluginsDir -Filter '*.aex' -File -ErrorAction SilentlyContinue |
                   Where-Object { $_.Name -match '^3DSway' -and $PluginNames -inotcontains $_.Name })
        foreach ($o in $extra) {
            Write-Warn2 ("Plug-ins 里还有另一个 {0}，两个同时存在可能互相干扰。" -f $o.Name)
            Write-Note  ("    del `"" + $o.FullName + "`"")
        }
    }

    # ---------------- 结果 ----------------
    Write-Host ''
    Write-Host '------------------------------------------------------------' -ForegroundColor Cyan
    if ($DryRun) {
        Write-Host '  演练结束（没有写入任何文件）。' -ForegroundColor Yellow
    } else {
        Write-Host '  安装完成：' -ForegroundColor Green
        foreach ($r in $results) {
            Write-Host ("    [OK] {0,-17} {1,10:N0} 字节" -f $r.项目, $r.大小) -ForegroundColor Green
            Write-Host ("         {0}" -f $r.目标) -ForegroundColor Gray
            Write-Host ("         {0}   SHA256 {1}" -f $r.状态, $r.校验) -ForegroundColor DarkGray
        }
    }

    Write-Host ''
    Write-Host '  接下来：' -ForegroundColor White
    Write-Host '    1) 启动（或重启）After Effects —— .aex 只在 AE 启动时加载，装完必须重启才生效。'
    Write-Host '    2) 添加素材图层后，在「效果(Effect)」菜单里找到 Sway > 3D Sway。'
    Write-Host '    3) 想回退：把目标目录里的 3DSway.aex.bak 改回原名即可（覆盖前会自动生成 .bak）。'
    Write-Host '------------------------------------------------------------' -ForegroundColor Cyan
    return 0
}

# ---------------------------------------------------------------------------
# 运行（-Pause 时无论成败都停一下，双击运行才看得到结果）
# ---------------------------------------------------------------------------
$exitCode = 0
try {
    $exitCode = Invoke-Main
} catch {
    if ($_.Exception.Message -eq 'QUIT') {
        Write-Host ''
        Write-Host '  已取消，未做任何改动。' -ForegroundColor Yellow
        $exitCode = 2
    } else {
        Write-Host ''
        Write-Err2 $_.Exception.Message
        Write-Host ''
        Write-Host '  安装失败。' -ForegroundColor Red
        $exitCode = 1
    }
} finally {
    if ($Pause) {
        Write-Host ''
        [void](Read-Host '按回车键关闭窗口')
    }
}
exit $exitCode
