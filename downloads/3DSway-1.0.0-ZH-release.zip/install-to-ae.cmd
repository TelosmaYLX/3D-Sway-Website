@echo off
rem ---------------------------------------------------------------
rem  install-to-ae.cmd - double-click launcher for install-to-ae.ps1
rem  Copies 3DSway.aex (next to this file) into the local Adobe
rem  After Effects "Support Files\Plug-ins" folder.
rem  Pass extra options through, e.g.:
rem      install-to-ae.cmd -DryRun
rem      install-to-ae.cmd -AeDir "D:\Adobe\Adobe After Effects 2026"
rem ---------------------------------------------------------------
setlocal
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install-to-ae.ps1" -Pause %*
set "RC=%ERRORLEVEL%"
endlocal & exit /b %RC%
